package com.tkelly.splitthebill;

import android.widget.TextView;


public class ItemSelectViewHolder {

    public TextView nameText;
    public TextView qtyText;
    public TextView costText;

}

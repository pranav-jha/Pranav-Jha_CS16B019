package com.tkelly.splitthebill;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

/*
 * A class which stores information about a single party member
 *
 * Members:
 *  name - a String containing the name of this payer
 *  amt_owed - a double containing the amount this payer owes
 */
public class Payer {

    // Payer members
    private String name;
    private double amt_owed;


    public Payer(String payer_name) {
        name = payer_name;
        amt_owed = 0d;
    }

    // Get methods
    public String getName() { return name; }
    public double getAmtOwed() { return amt_owed; }

    // Set method
    public void setName(String new_name) { name = new_name; }


    public void clearAmtOwed() { amt_owed = 0d; }


    public void updateAmtOwed(double amount) { amt_owed += amount; }


    public String getResult(double tax) {
        NumberFormat formatter= NumberFormat.getCurrencyInstance(new Locale("en","IN"));
        if (amt_owed > 0d) {
            return "<b>" + name + "'s expenditure: " +
                   formatter.format(amt_owed * tax)+"</b><br/>";
                    // NumberFormat.getCurrencyInstance().format(amt_owed * tax) +

        } else { return ""; }
    }


    public String getTipGuide() {
       return "";
    }

}

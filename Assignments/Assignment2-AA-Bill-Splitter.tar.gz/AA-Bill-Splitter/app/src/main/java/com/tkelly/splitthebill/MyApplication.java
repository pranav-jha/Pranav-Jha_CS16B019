package com.tkelly.splitthebill;

import android.app.Application;
import java.util.ArrayList;
import java.util.HashMap;


public class MyApplication extends Application {
    
    private ArrayList<Item> items;
    private ArrayList<Payer> payers;
    private double tax;

    public MyApplication() {
        super();
        items = new ArrayList<>();
        payers = new ArrayList<>();
        tax = 0d;
    }


    public Item getItem(int idx) {
        try {
            return items.get(idx);
        } catch (IndexOutOfBoundsException e) {
            return null;
        }
    }


    public Payer getPayer(int idx) {
        try {
            return payers.get(idx);
        } catch (IndexOutOfBoundsException e) {
            return null;
        }
    }

    // Get methods
    public ArrayList<Item> getItems() { return items; }
    public ArrayList<Payer> getPayers() { return payers; }
    public double getTax() { return tax; }
    public int getNumItems() { return items.size(); }
    public int getNumPayers() { return payers.size(); }

    // Set method
    public void setTax(double new_tax) { tax = new_tax; }

    // Clear methods
    public void clearAmtsOwed() { for (Payer payer : payers) payer.clearAmtOwed(); }
    public void clearAllPayments() { for (Item item : items) item.clearPayments(); }
    public void clearCompleted() { for (Item item : items) item.setCompleted(false); }


    public boolean payersIsEmpty() { return payers.isEmpty(); }


    public boolean itemsIsEmpty() { return items.isEmpty(); }


    public boolean allItemsAreCompleted() {
        boolean all_items_completed = true;
        for (Item item : items) {
            all_items_completed &= item.isCompleted();
        }
        return all_items_completed;
    }



    public void updateAmtsOwed() {
        clearAmtsOwed();
        for (Item item : items) {
            HashMap<Integer, Double> payments = item.getPayments();
            for (int i : payments.keySet()) {
                payers.get(i).updateAmtOwed(payments.get(i));
            }
        }
    }


    public double subTotal() {
        double total = 0d;
        for (Item item : items) {
            total += item.getCost() * item.getQty();
        }
        return total;
    }
}

package com.tkelly.splitthebill;

import android.content.Context;
import android.text.InputType;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;


public class EditCurrency extends EditText {

    public EditCurrency(Context context) {
        super(context);
        init();
    }

    public EditCurrency(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public EditCurrency(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }


    public double getTextAsDouble() throws ParseException {
        String s = getText().toString();
        NumberFormat formatter= NumberFormat.getCurrencyInstance(new Locale("en","IN"));
        return formatter.parse(s).doubleValue();
    }

    private void init() {
        NumberFormat formatter= NumberFormat.getCurrencyInstance(new Locale("en","IN"));
        String zero_currency = formatter.format( 0);

        //String zero_currency = NumberFormat.getCurrencyInstance().format(0);
        setInputType(InputType.TYPE_CLASS_NUMBER);
        setText(zero_currency);
        setSelection(zero_currency.length());

        addTextChangedListener(new CurrencyWatcher(this));

        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                setSelection(getText().length());
            }
        });
    }

}

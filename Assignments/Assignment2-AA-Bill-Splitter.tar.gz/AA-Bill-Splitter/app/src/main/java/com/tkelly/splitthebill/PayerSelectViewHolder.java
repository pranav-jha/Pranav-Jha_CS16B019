package com.tkelly.splitthebill;

import android.widget.CheckBox;
import android.widget.TextView;


public class PayerSelectViewHolder {

    public CheckBox checkBox;
    public TextView textView;

}
